"""
database.py - SQLite persistence for ICU Agent OS.

Schema note: patient_memory is its OWN table. Agent scratchpad / running
context does not get written into the clinical `notes` field, so the meaning
of a clinical note is never corrupted.
"""

import sqlite3
import json
from datetime import datetime, date

SCHEMA = """
CREATE TABLE IF NOT EXISTS patients (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    mrn         TEXT UNIQUE,
    name        TEXT NOT NULL,
    age         INTEGER,
    sex         TEXT,
    bed         TEXT,
    diagnosis   TEXT,
    status      TEXT DEFAULT 'active',
    admitted_on TEXT
);
CREATE TABLE IF NOT EXISTS daily_updates (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id  INTEGER NOT NULL REFERENCES patients(id),
    upd_date    TEXT NOT NULL,
    shift       TEXT,
    vitals_json TEXT,
    note        TEXT,
    assessment  TEXT,
    plan        TEXT,
    events      TEXT,
    created_at  TEXT
);
CREATE TABLE IF NOT EXISTS patient_memory (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id  INTEGER NOT NULL REFERENCES patients(id),
    mkey        TEXT NOT NULL,
    mvalue      TEXT,
    updated_at  TEXT,
    UNIQUE(patient_id, mkey)
);
"""


class DB:
    def __init__(self, path="vatsal_icu.db"):
        self.conn = sqlite3.connect(path, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self.conn.commit()

    # -- patients ----------------------------------------------------------
    def add_patient(self, name, mrn=None, age=None, sex=None, bed=None, diagnosis=None):
        cur = self.conn.execute(
            "INSERT INTO patients(mrn,name,age,sex,bed,diagnosis,admitted_on) "
            "VALUES(?,?,?,?,?,?,?)",
            (mrn, name, age, sex, bed, diagnosis, date.today().isoformat()))
        self.conn.commit()
        return cur.lastrowid

    def active_patients(self):
        return [dict(r) for r in self.conn.execute(
            "SELECT * FROM patients WHERE status='active' ORDER BY bed")]

    def get_patient(self, pid):
        r = self.conn.execute("SELECT * FROM patients WHERE id=?", (pid,)).fetchone()
        return dict(r) if r else None

    def discharge(self, pid):
        self.conn.execute("UPDATE patients SET status='discharged' WHERE id=?", (pid,))
        self.conn.commit()

    # -- daily updates -----------------------------------------------------
    def add_update(self, patient_id, vitals=None, note="", assessment="",
                   plan="", events="", shift="Morning"):
        self.conn.execute(
            "INSERT INTO daily_updates(patient_id,upd_date,shift,vitals_json,"
            "note,assessment,plan,events,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (patient_id, date.today().isoformat(), shift,
             json.dumps(vitals or {}), note, assessment, plan, events,
             datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()

    def updates_for(self, patient_id, limit=10):
        rows = self.conn.execute(
            "SELECT * FROM daily_updates WHERE patient_id=? "
            "ORDER BY id DESC LIMIT ?", (patient_id, limit))
        out = []
        for r in rows:
            d = dict(r)
            d["vitals"] = json.loads(d.pop("vitals_json") or "{}")
            out.append(d)
        return out

    # -- memory ------------------------------------------------------------
    def set_memory(self, patient_id, key, value):
        self.conn.execute(
            "INSERT INTO patient_memory(patient_id,mkey,mvalue,updated_at) "
            "VALUES(?,?,?,?) ON CONFLICT(patient_id,mkey) DO UPDATE SET "
            "mvalue=excluded.mvalue, updated_at=excluded.updated_at",
            (patient_id, key, value, datetime.now().isoformat(timespec="seconds")))
        self.conn.commit()

    def get_memory(self, patient_id):
        return {r["mkey"]: r["mvalue"] for r in self.conn.execute(
            "SELECT mkey,mvalue FROM patient_memory WHERE patient_id=?", (patient_id,))}
