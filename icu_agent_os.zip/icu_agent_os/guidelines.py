"""
guidelines.py - Local, searchable guideline store.

The retrieval here is deterministic keyword ranking over YOUR stored content.
The LLM never "recalls" a guideline from training - it can only summarise text
that is physically present in this file / DB. That is the difference between a
citable protocol and a hallucination.

CONTENT MUST BE LOCALLY VALIDATED. The starters below are compact summaries of
widely accepted bundles; adapt to your unit protocol and current editions
before clinical use.
"""

import re

GUIDELINES = [
    {
        "title": "Sepsis & Septic Shock",
        "category": "Sepsis/Shock",
        "keywords": "sepsis septic shock lactate antibiotics vasopressor noradrenaline map fluid bundle",
        "content": (
            "Hour-1 bundle: measure lactate (repeat if >2). Obtain blood cultures "
            "BEFORE antibiotics. Give broad-spectrum antibiotics early. For "
            "hypotension or lactate >=4: 30 mL/kg crystalloid, reassess with dynamic "
            "measures. Start norepinephrine (first-line vasopressor) for MAP >=65 "
            "mmHg. Add vasopressin/steroids per refractory shock. Source-control ASAP."),
    },
    {
        "title": "ARDS & Lung-Protective Ventilation",
        "category": "Respiratory",
        "keywords": "ards hypoxia ventilation tidal volume peep prone plateau berlin oxygenation",
        "content": (
            "Berlin definition (mild/moderate/severe by PaO2/FiO2 with PEEP >=5). "
            "Vt 6 mL/kg predicted body weight; plateau pressure <30 cmH2O; permissive "
            "hypercapnia acceptable. Titrate PEEP to oxygenation/compliance. Prone "
            "positioning >=12 h/day if PaO2/FiO2 <150. Conservative fluids once "
            "resuscitated. Consider neuromuscular blockade / ECMO in severe refractory."),
    },
    {
        "title": "Acute Kidney Injury (KDIGO)",
        "category": "Renal/Metabolic",
        "keywords": "aki kidney creatinine urine output kdigo rrt dialysis nephrotoxin",
        "content": (
            "Stage by creatinine rise and urine output. Optimise volume status and "
            "perfusion pressure, stop nephrotoxins, adjust drug doses, avoid contrast "
            "when feasible. Consider RRT for refractory Acidosis, Electrolytes (K+), "
            "Intoxication, Overload, Uraemia (AEIOU) rather than by a creatinine number "
            "alone."),
    },
    {
        "title": "ICU Delirium (PADIS / ABCDEF)",
        "category": "Neuro",
        "keywords": "delirium sedation cam-icu agitation benzodiazepine mobilization padis abcdef pain",
        "content": (
            "Assess with CAM-ICU / ICDSC each shift. ABCDEF bundle: Assess/treat pain, "
            "Both spontaneous awakening + breathing trials, Choice of light sedation "
            "(avoid benzodiazepines where possible; prefer propofol/dexmedetomidine), "
            "Delirium monitoring, Early mobility, Family engagement. Correct reversible "
            "causes (hypoxia, sepsis, metabolic, drugs), protect sleep."),
    },
    {
        "title": "Ventilator-Associated Pneumonia (VAP)",
        "category": "Respiratory",
        "keywords": "vap ventilator pneumonia bundle antibiotic de-escalation oral care sedation",
        "content": (
            "Prevention bundle: head-of-bed 30-45 degrees, daily sedation interruption "
            "with spontaneous breathing trial, oral care, DVT and stress-ulcer "
            "prophylaxis, subglottic secretion drainage where available. Treatment: "
            "empiric cover guided by LOCAL antibiogram, obtain respiratory cultures, "
            "de-escalate at 48-72 h, target ~7 days for uncomplicated response."),
    },
    {
        "title": "DKA & HHS",
        "category": "Renal/Metabolic",
        "keywords": "dka hhs ketoacidosis hyperglycemia insulin potassium fluids anion gap sglt2",
        "content": (
            "Fluids first (isotonic saline), then insulin infusion ~0.1 U/kg/h AFTER "
            "confirming K+ >=3.3. Replace potassium aggressively; hold insulin if K+ "
            "<3.3. Add dextrose when glucose ~200-250 mg/dL to continue insulin and "
            "clear ketones. Hourly glucose, 2-4 hourly electrolytes. Search for "
            "precipitant. Beware euglycemic DKA with SGLT2 inhibitors. HHS: slower "
            "correction, higher fluid deficit, watch osmolality."),
    },
]


class GuidelineStore:
    def __init__(self, guidelines=None):
        self.items = guidelines or GUIDELINES

    def search(self, query, top=3):
        terms = [t for t in re.findall(r"[a-z0-9]+", (query or "").lower()) if len(t) > 2]
        scored = []
        for g in self.items:
            hay = (g["title"] + " " + g["keywords"] + " " + g["content"]).lower()
            score = sum(hay.count(t) for t in terms)
            # title hits are worth more
            score += 3 * sum(g["title"].lower().count(t) for t in terms)
            if score:
                scored.append((score, g))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [g for _, g in scored[:top]]

    def titles(self):
        return [g["title"] for g in self.items]
