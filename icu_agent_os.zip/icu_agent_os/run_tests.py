"""Exercises every deterministic component (no LLM, no network)."""
import icu_scores as sc
from phi import redact, restore
from database import DB
from guidelines import GuidelineStore
from agents import Router, Context, ScoringAgent, DifferentialAgent
from llm import LLMClient

def test_scores():
    assert sc.qsofa(24, 90, 15).score == 2
    assert sc.sofa(pao2_fio2=250, on_respiratory_support=True, platelets=80,
                   bilirubin=3.0, map_mmhg=65, gcs=13, creatinine=2.5).score == 10
    assert sc.apache2(age=60, temperature_c=39.0, map_mmhg=65, heart_rate=130,
                      resp_rate=30, fio2=0.4, pao2=70, arterial_ph=7.30, sodium=148,
                      potassium=5.0, creatinine=2.5, hematocrit=32, wbc=18, gcs=13).score == 20
    print("scores            OK")

def test_phi():
    p = {"name": "Ramesh Patil", "mrn": "MRN4471", "bed": "3"}
    txt = "Ramesh Patil in bed 3 (MRN4471), phone 9822011234, id 1234 5678 9012"
    red, mp = redact(txt, p)
    assert "Ramesh" not in red and "MRN4471" not in red
    assert "9822011234" not in red and "1234 5678 9012" not in red
    assert restore(red, mp).startswith("Ramesh Patil")
    print("phi redaction     OK")

def test_db():
    db = DB(":memory:")
    pid = db.add_patient("Test", mrn="M1", age=60, bed="1", diagnosis="Sepsis")
    db.add_update(pid, vitals={"hr": 110}, note="stable", shift="Morning")
    db.set_memory(pid, "weaning", "difficult - failed SBT x2")
    db.set_memory(pid, "weaning", "passed SBT today")  # upsert
    assert len(db.active_patients()) == 1
    assert db.updates_for(pid)[0]["vitals"]["hr"] == 110
    assert db.get_memory(pid)["weaning"] == "passed SBT today"
    print("database + memory OK")

def test_guidelines():
    gs = GuidelineStore()
    hits = gs.search("how do I manage septic shock lactate")
    assert hits and hits[0]["title"] == "Sepsis & Septic Shock"
    assert gs.search("prone ventilation hypoxia")[0]["title"].startswith("ARDS")
    print("guideline search  OK")

def test_router():
    r = Router()
    gs = GuidelineStore()
    # scoring path, deterministic
    ctx = Context(message="calculate qSOFA", values={"resp_rate": 24, "sbp": 90, "gcs": 15})
    resp = r.route(ctx)
    assert resp.agent == "scoring" and "qSOFA: 2" in resp.text and not resp.used_llm
    # differential path, rule-based
    ctx = Context(message="differential please",
                  values={"findings": ["hypotension", "lactate_high", "warm"]})
    resp = r.route(ctx)
    assert "Septic" in resp.text and not resp.used_llm
    # guideline path
    ctx = Context(message="sepsis protocol", guidelines=gs)
    resp = r.route(ctx)
    assert "Sepsis" in resp.text
    print("router            OK")

def test_llm_offline():
    c = LLMClient(base_url="https://api.openai.com/v1", api_key="")
    assert not c.configured
    resp = c.chat("sys", "Patient Ramesh, hr 120", patient={"name": "Ramesh"})
    assert resp.available is False and "template" in resp.note.lower()
    print("llm offline       OK")

if __name__ == "__main__":
    for t in (test_scores, test_phi, test_db, test_guidelines, test_router, test_llm_offline):
        t()
    print("\nAll deterministic components passed.")
