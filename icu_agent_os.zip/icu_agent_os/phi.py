"""
phi.py - First-line PHI reducer.

Before ANY patient text is sent to an external LLM, run it through redact().
This replaces known record identifiers (name, MRN, bed) with stable tokens and
scrubs common India-context identifiers (Aadhaar, phone, email).

This is a risk-reducer, NOT a certified de-identification pipeline. The safest
posture under the DPDP Act is to point the LLM client at a LOCAL model so no
patient data leaves the hospital at all (see llm.py -> base_url).
"""

import re

_AADHAAR = re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b")
_PHONE = re.compile(r"\b(?:\+91[\-\s]?)?[6-9]\d{9}\b")
_EMAIL = re.compile(r"\b[\w.+-]+@[\w-]+\.[\w.-]+\b")


def redact(text, patient=None):
    """Return (redacted_text, mapping). mapping lets you re-insert names locally
    when displaying the LLM's output back to the clinician."""
    if not text:
        return text, {}
    mapping = {}
    out = text

    if patient:
        name = (patient.get("name") or "").strip()
        mrn = (patient.get("mrn") or "").strip()
        bed = str(patient.get("bed") or "").strip()
        if name:
            out = re.sub(re.escape(name), "[PATIENT]", out, flags=re.IGNORECASE)
            mapping["[PATIENT]"] = name
        if mrn:
            out = out.replace(mrn, "[MRN]")
            mapping["[MRN]"] = mrn
        if bed:
            out = re.sub(rf"\bbed\s*{re.escape(bed)}\b", "[BED]", out, flags=re.IGNORECASE)

    out = _AADHAAR.sub("[ID]", out)
    out = _PHONE.sub("[PHONE]", out)
    out = _EMAIL.sub("[EMAIL]", out)
    return out, mapping


def restore(text, mapping):
    """Re-insert local identifiers into an LLM response for on-screen display."""
    if not text:
        return text
    for token, real in mapping.items():
        text = text.replace(token, real)
    return text
