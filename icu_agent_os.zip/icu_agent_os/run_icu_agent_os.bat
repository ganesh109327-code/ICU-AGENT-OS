@echo off
REM ICU Agent OS launcher for Windows. Requires Python 3.10+ (add to PATH).
cd /d "%~dp0"
where python >nul 2>nul || (echo Python not found. Install from python.org and tick "Add to PATH". & pause & exit /b)
pip show streamlit >nul 2>nul || (echo Installing dependencies (first run only)... & pip install -r requirements.txt)
echo Starting ICU Agent OS...
streamlit run app.py
pause
