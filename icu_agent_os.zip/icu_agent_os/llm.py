"""
llm.py - Provider-agnostic LLM client (stdlib only, no SDK dependency).

Works with any OpenAI-compatible /chat/completions endpoint:
  * OpenAI       base_url=https://api.openai.com/v1
  * Groq         base_url=https://api.groq.com/openai/v1
  * Local model  base_url=http://localhost:11434/v1  (Ollama)  <-- best for DPDP:
                 patient data never leaves the hospital.

Two guarantees the app relies on:
  1. Every prompt is PHI-redacted before it leaves this process.
  2. If no key/endpoint is configured or the call fails, chat() returns
     available=False with a safe message instead of raising. The whole app
     stays usable offline; only LLM *phrasing* is unavailable.
"""

import os
import json
import urllib.request
import urllib.error
from dataclasses import dataclass

from phi import redact, restore


@dataclass
class LLMResponse:
    text: str
    available: bool
    note: str = ""


class LLMClient:
    def __init__(self, base_url=None, api_key=None, model=None):
        self.base_url = (base_url or os.getenv("ICU_LLM_BASE_URL")
                         or "https://api.openai.com/v1").rstrip("/")
        self.api_key = api_key or os.getenv("ICU_LLM_API_KEY", "")
        self.model = model or os.getenv("ICU_LLM_MODEL", "gpt-4o-mini")

    @property
    def configured(self):
        # Local endpoints often need no key; remote ones do.
        return bool(self.api_key) or "localhost" in self.base_url or "127.0.0.1" in self.base_url

    def chat(self, system, user, patient=None, temperature=0.2, max_tokens=800):
        if not self.configured:
            return LLMResponse(
                "", available=False,
                note="No LLM configured - showing template output. Set a key or a "
                     "local model endpoint to enable drafting.")

        safe_user, mapping = redact(user, patient)
        payload = {
            "model": self.model,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": safe_user},
            ],
        }
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     "Authorization": f"Bearer {self.api_key}"},
            method="POST")
        try:
            with urllib.request.urlopen(req, timeout=45) as r:
                data = json.loads(r.read().decode())
            text = data["choices"][0]["message"]["content"]
            return LLMResponse(restore(text, mapping), available=True)
        except (urllib.error.URLError, KeyError, TimeoutError, json.JSONDecodeError) as e:
            return LLMResponse("", available=False,
                               note=f"LLM call failed ({type(e).__name__}); using template.")
